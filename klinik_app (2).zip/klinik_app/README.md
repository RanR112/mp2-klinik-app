# klinik_app

Project Flutter untuk mata kuliah Mobile Programming II — mengikuti **seluruh modul** (Pertemuan 2 s/d 13; Pertemuan 1/7/8/9/14-16 tidak ada kode aplikasi — lihat catatan di bawah).

## ⚠️ Langkah WAJIB sebelum dijalankan: setup mockapi.io

Mulai Pertemuan 9, aplikasi ini mengambil data Poli dari REST API (bukan data statis lagi). API-nya pakai **mockapi.io** (mock backend gratis). Kamu harus bikin punya sendiri:

1. Buka https://mockapi.io/ → daftar/login.
2. Buat project baru, kasih nama `klinik`.
3. Di dalam project itu, klik **New Resource** → isi:
   - Resource name: `poli`
   - Schema: hapus field bawaan, sisakan `id` (Object ID) lalu tambah field `nama_poli` dengan tipe `String`.
   - Klik **Create**.
4. Setelah dibuat, salin **API endpoint** yang muncul, contoh: `https://63588b60c27556d2893f7a12.mockapi.io/`.
5. Buka `lib/helpers/api_client.dart`, ganti nilai `kBaseUrl` dengan endpoint milikmu:
   ```dart
   const String kBaseUrl = 'https://xxxxxxxxxxxxxxxx.mockapi.io/';
   ```

Tanpa langkah ini, halaman **Data Poli** akan error / loading terus karena `kBaseUrl` masih placeholder.

## Login

Login masih dummy (belum ke API), sesuai modul Pertemuan 11:
- **Username:** `admin`
- **Password:** `admin`

## Struktur folder

```
klinik_app/
├── android/ ios/ web/ test/      # folder platform standar
├── lib/
│   ├── main.dart                 # cek token → arahkan ke Login atau Beranda (P10)
│   ├── model/
│   │   └── poli.dart             # class Poli + fromJson/toJson (P11)
│   ├── helpers/
│   │   ├── user_info.dart        # simpan/ambil token login via SharedPreferences (P10)
│   │   └── api_client.dart       # wrapper dio utk GET/POST/PUT/DELETE ke mockapi (P11)
│   ├── service/
│   │   ├── login_service.dart    # dummy login admin/admin (P11)
│   │   └── poli_service.dart     # listData/simpan/ubah/getById/hapus ke API (P11)
│   ├── widget/
│   │   └── sidebar.dart          # Drawer menu: Beranda, Poli, Pegawai, Pasien, Keluar (P6)
│   └── ui/
│       ├── beranda.dart          # halaman awal setelah login (P6)
│       ├── login.dart            # form login (P6, logic API di P11)
│       ├── poli_page.dart        # list poli dari API via StreamBuilder (P12)
│       ├── poli_item.dart        # widget Card per item poli (P3)
│       ├── poli_form.dart        # Tambah Poli → POST ke API (P12)
│       ├── poli_detail.dart      # Detail poli dari API, tombol Ubah/Hapus (P13)
│       └── poli_update_form.dart # Ubah Poli → GET + PUT ke API (P13)
└── pubspec.yaml                  # + dio, shared_preferences
```

Semua AppBar (Beranda, Data Poli, Tambah Poli, Detail Poli, Ubah Poli) pakai
`backgroundColor: Color(0xFF2196F3)` + `foregroundColor: Colors.white`.

## Cara menjalankan

1. Isi `kBaseUrl` di `lib/helpers/api_client.dart` (lihat bagian setup mockapi.io di atas).
2. `flutter pub get`
3. `flutter run`

## Alur aplikasi

1. **main.dart** cek apakah ada token tersimpan (SharedPreferences). Belum ada → buka **Login**. Sudah ada → langsung ke **Beranda**.
2. **Login**: isi `admin`/`admin` → `LoginService` simpan token dummy → masuk **Beranda**. Salah → dialog "Username atau Password Tidak Valid".
3. **Beranda** & **Data Poli** punya **Sidebar** (drawer): menu Beranda, Poli, Pegawai (belum ada halamannya), Pasien (belum ada halamannya), dan Keluar (hapus token, kembali ke Login).
4. **Data Poli**: `StreamBuilder` ambil list dari `PoliService().listData()` (GET ke mockapi). Ikon **+** buka **Tambah Poli**.
5. **Tambah Poli**: submit → `PoliService().simpan()` (POST) → lanjut ke **Detail Poli** dengan data hasil API (sudah ada `id`).
6. **Detail Poli**: ambil ulang data by id (GET) lewat `StreamBuilder`. Tombol **Ubah** → **Ubah Poli**. Tombol **Hapus** → dialog konfirmasi → **YA** memanggil `PoliService().hapus()` (DELETE) lalu kembali ke Data Poli.
7. **Ubah Poli**: `initState` ambil data lama (GET), field terisi otomatis. Submit → `PoliService().ubah()` (PUT) → kembali ke **Detail Poli** dengan data baru.

## Catatan pertemuan yang tidak ada kode aplikasi

- **Pertemuan 1**: penjelasan tugas project saja.
- **Pertemuan 7**: materi konsep API, arsitektur API, install Postman (tidak ada kode di app).
- **Pertemuan 8 & 16**: UTS / UAS.
- **Pertemuan 9**: setup API di mockapi.io (dilakukan di website mockapi.io, bukan di kode — lihat bagian setup di atas).
- **Pertemuan 14-15**: presentasi projek.

## Belum termasuk (TUGAS mandiri di modul)

Modul meminta mengulangi seluruh alur (list, detail, tambah, ubah, hapus + koneksi API) untuk data **Pegawai** dan **Pasien** sebagai latihan mandiri. Menu "Pegawai" dan "Pasien" di sidebar sudah ada tapi `onTap`-nya masih kosong — belum dibuatkan halamannya. Tinggal bilang kalau mau saya buatkan juga dengan pola yang sama persis seperti Poli.
