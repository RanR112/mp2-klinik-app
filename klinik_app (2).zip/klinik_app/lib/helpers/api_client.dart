import 'package:dio/dio.dart';

// PENTING: ganti baseUrl ini dengan API endpoint mockapi.io milikmu sendiri.
// Caranya (sesuai Pertemuan 9 modul):
// 1. Buat akun di https://mockapi.io/
// 2. Buat project baru bernama "klinik"
// 3. Buat resource baru bernama "poli" dengan schema: nama_poli (String)
// 4. Salin "API endpoint" yang muncul (https://xxxxxxxx.mockapi.io/) ke baseUrl di bawah ini
const String kBaseUrl = 'https://REPLACE_WITH_YOUR_MOCKAPI_ID.mockapi.io/';

final Dio dio = Dio(BaseOptions(
    baseUrl: kBaseUrl,
    connectTimeout: const Duration(seconds: 5),
    receiveTimeout: const Duration(seconds: 3)));

class ApiClient {
  Future<Response> get(String path) async {
    try {
      final response = await dio.get(Uri.encodeFull(path));
      return response;
    } on DioException catch (e) {
      throw Exception(e.message);
    }
  }

  Future<Response> post(String path, dynamic data) async {
    try {
      final response = await dio.post(Uri.encodeFull(path), data: data);
      return response;
    } on DioException catch (e) {
      throw Exception(e.message);
    }
  }

  Future<Response> put(String path, dynamic data) async {
    try {
      final response = await dio.put(Uri.encodeFull(path), data: data);
      return response;
    } on DioException catch (e) {
      throw Exception(e.message);
    }
  }

  Future<Response> delete(String path) async {
    try {
      final response = await dio.delete(Uri.encodeFull(path));
      return response;
    } on DioException catch (e) {
      throw Exception(e.message);
    }
  }
}
