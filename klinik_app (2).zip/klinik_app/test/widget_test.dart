// Basic smoke test for klinik_app.
//
// Karena aplikasi sekarang mengambil data dari API (mockapi.io) dan memakai
// SharedPreferences untuk cek status login, test ini hanya memastikan
// halaman Login tampil dengan benar saat aplikasi pertama kali dibuka
// (belum ada token tersimpan).

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:klinik_app/ui/login.dart';

void main() {
  testWidgets('Halaman Login menampilkan form login',
      (WidgetTester tester) async {
    await tester.pumpWidget(MaterialApp(home: Login()));

    expect(find.text('Login Admin'), findsOneWidget);
    expect(find.text('Username'), findsOneWidget);
    expect(find.text('Password'), findsOneWidget);
    expect(find.text('Login'), findsOneWidget);
  });
}
